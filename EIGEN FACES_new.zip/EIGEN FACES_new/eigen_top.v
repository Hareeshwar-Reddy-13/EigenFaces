module eigen_top #(

    parameter PIXELS = 4096,
              USERS_FACES=5,
              PARALLEL_MACS=16,
              EIGEN_FACES = 20,
              ACC_WIDTH=10+16+$clog2(4096)

)
(
    input clk ,reset, bram_loaded , start ,
    output reg [$clog2(USERS_FACES)-1 :0] user_id
);


reg [7:0] ip_img [PIXELS-1 : 0]; //input image in the bram
reg signed [8:0] mean_pixels [PIXELS-1 : 0]; //bram for the mean pixels in the subtract block
reg signed [15:0] weights_mac [EIGEN_FACES*4096 - 1 : 0] ;//each eigen face has its own 4096 weights
reg [$clog2(PIXELS/PARALLEL_MACS)-1 : 0] ip_cycle_ctr; //keeps track of the the cycles for the 256 dycles                   

wire mac_ready; //comes from the mac block
reg [$clog2(EIGEN_FACES)-1:0] eigen_face_ctr; // comes form the mac block , notifies when an eigen faces is completed

// CONNECTING THE SUBTRACTION BLOCK //

reg [127:0] submod_ip_pixels; // pixel 128 bit input to the subtraction block
reg signed [143 :0] submod_ip_mean; //144 bit pixel mean input to the subtraction block
wire [159:0] submod_op_centred_pixels; //10 bit each total 160bit output of subtraction block

integer g;
always@(*) begin
    for(g=0 ; g< PARALLEL_MACS ; g=g+1) begin

         submod_ip_pixels[ g*8 +: 8] = ip_img[ ip_cycle_ctr*PARALLEL_MACS + g]; //flattening the pixels to 
         submod_ip_mean [ g*9 +: 9] = mean_pixels[ ip_cycle_ctr*PARALLEL_MACS + g];
    end
end


always@(posedge clk or posedge reset) begin

    
        if(reset ) begin //when the iterations for eigen faces is done it resets 
            ip_cycle_ctr <= 0;
            eigen_face_ctr<=0;
            
        end
        else if(!mac_ready && start && bram_loaded) begin 
            if( ip_cycle_ctr == PIXELS/PARALLEL_MACS -1) begin
                ip_cycle_ctr <= 0;
                if(eigen_face_ctr < EIGEN_FACES-1 )
                    eigen_face_ctr<=eigen_face_ctr + 1;
            end
            else
                ip_cycle_ctr <= ip_cycle_ctr + 1; //counts the increments

end
end

eigen_subtract  # (
    .PIXELS_PER_CYCLE (PARALLEL_MACS)
) subtract(
    .clk(clk) , 
    .reset(reset) , 
    .pixels(submod_ip_pixels) , 
    .mean_pixels(submod_ip_mean) , 
    .centred_pixels(submod_op_centred_pixels)
);

// Connecting the MAC block //

reg signed [(PARALLEL_MACS*16)-1:0] macmod_ip_weight;
wire signed [(EIGEN_FACES*ACC_WIDTH)-1:0] macmod_op_acc;

always@(*) begin
    for(g=0 ; g< PARALLEL_MACS ; g=g+1) begin
         macmod_ip_weight [ g*16 +: 16] = weights_mac[ (eigen_face_ctr * PIXELS) + (ip_cycle_ctr * PARALLEL_MACS) + g];
    
end
end

eigen_mac  #(
    .PARALLEL_MACS(PARALLEL_MACS),
    .ACC_WIDTH(ACC_WIDTH),
    .EIGEN_FACES(EIGEN_FACES)
    
)macunit(
    .clk(clk),
    .reset(reset),
    .centred_pixels (submod_op_centred_pixels),
    .weights (macmod_ip_weight) ,
    //input sub_ready, -> no need continuous pipeline
    .acc(macmod_op_acc),
    .mac_ready(mac_ready)
);

// Dummy assignment to stop Vivado from deleting your hard work
always @(posedge clk) begin
    user_id <= macmod_op_acc[ACC_WIDTH-1 : ACC_WIDTH-$clog2(USERS_FACES)];
end

endmodule